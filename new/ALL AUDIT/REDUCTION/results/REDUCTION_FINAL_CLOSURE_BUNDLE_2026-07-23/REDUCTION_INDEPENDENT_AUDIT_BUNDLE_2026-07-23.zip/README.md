# REDUCTION Independent Audit Bundle

Primary report:
- `REDUCTION_INDEPENDENT_AUDIT_2026-07-23.md`

Independent sensitivity outputs:
- `paired_regret_sensitivity.csv`
- `looso_selection_frequency.csv`
- `looso_selection_evaluations.csv`
- `gpu_regime_ratios.csv`
- `pareto_front_N16M.csv`
- `stability_and_outlier_summary.csv`
- `worst_stability_configurations.csv`
- `independent_audit_checks.csv`

The uploaded archives contain manifests, hashes, validation reports,
session medians and aggregate outputs, but not the 8,100 raw campaign rows
or source/runner bytes. No measurement value was changed or removed.
