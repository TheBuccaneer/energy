#!/usr/bin/env python3
"""Descriptive post-selection extension for STREAM within-platform regret.

This script compares, for each CPU platform and problem size, the exact
runtime-minimizing configuration with the exact energy-minimizing configuration
selected from the same five session medians.  The result is explicitly
post-selection and descriptive; it is not confirmatory inference.

Usage:
  python stream_within_platform_exact_winner_regret.py \
      --session-medians unified_session_medians.csv \
      --configuration-summary unified_configuration_summary.csv \
      --output within_platform_exact_winner_regret.csv
"""
from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd

PRACTICAL_TOLERANCE = 0.02


def bootstrap_median_support(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = np.asarray(values, dtype=float)
    if x.ndim != 1 or len(x) != 5 or not np.all(np.isfinite(x)):
        raise ValueError("Expected exactly five finite session medians")
    indices = np.asarray(list(itertools.product(range(5), repeat=5)), dtype=int)
    draws = np.median(x[indices], axis=1)
    return np.unique(draws, return_counts=True)


def expanded_quantile_from_support(
    values: np.ndarray, weights: np.ndarray, q: float
) -> float:
    """Match numpy's default linear quantile on the conceptual expanded array."""
    order = np.argsort(values)
    v = np.asarray(values, dtype=float)[order]
    w = np.asarray(weights, dtype=np.int64)[order]
    cumulative = np.cumsum(w)
    total = int(cumulative[-1])
    position = (total - 1) * q
    lower_index = int(np.floor(position))
    upper_index = int(np.ceil(position))
    fraction = position - lower_index

    def kth(index: int) -> float:
        support_index = int(np.searchsorted(cumulative, index + 1, side="left"))
        return float(v[support_index])

    return (1.0 - fraction) * kth(lower_index) + fraction * kth(upper_index)


def exact_bootstrap_ratio_ci(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    a_values, a_counts = bootstrap_median_support(a)
    b_values, b_counts = bootstrap_median_support(b)
    if np.any(b_values <= 0):
        raise ValueError("Ratio denominator bootstrap support must be positive")
    ratios = (a_values[:, None] / b_values[None, :]).ravel()
    weights = (a_counts[:, None] * b_counts[None, :]).ravel()
    return (
        expanded_quantile_from_support(ratios, weights, 0.025),
        expanded_quantile_from_support(ratios, weights, 0.975),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session-medians", required=True, type=Path)
    parser.add_argument("--configuration-summary", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    sessions = pd.read_csv(args.session_medians)
    summary = pd.read_csv(args.configuration_summary)

    required_sessions = {
        "platform", "problem_size", "configuration", "session_number",
        "runtime_s", "energy_j",
    }
    required_summary = {
        "platform", "problem_size", "configuration",
        "runtime_s_median", "energy_j_median",
    }
    missing_s = required_sessions - set(sessions.columns)
    missing_c = required_summary - set(summary.columns)
    if missing_s or missing_c:
        raise ValueError(f"Missing columns: sessions={sorted(missing_s)}, summary={sorted(missing_c)}")

    rows: list[dict[str, object]] = []
    for platform in ("INTEL", "AMD"):
        platform_summary = summary[summary["platform"] == platform]
        for size in sorted(platform_summary["problem_size"].unique()):
            group = platform_summary[platform_summary["problem_size"] == size]
            runtime_row = group.loc[group["runtime_s_median"].astype(float).idxmin()]
            energy_row = group.loc[group["energy_j_median"].astype(float).idxmin()]
            runtime_config = str(runtime_row["configuration"])
            energy_config = str(energy_row["configuration"])

            runtime_sessions = sessions[
                (sessions["platform"] == platform)
                & (sessions["problem_size"] == size)
                & (sessions["configuration"] == runtime_config)
            ].sort_values("session_number")
            energy_sessions = sessions[
                (sessions["platform"] == platform)
                & (sessions["problem_size"] == size)
                & (sessions["configuration"] == energy_config)
            ].sort_values("session_number")

            if len(runtime_sessions) != 5 or len(energy_sessions) != 5:
                raise ValueError(
                    f"Expected five sessions for {platform} N={size}: "
                    f"runtime={len(runtime_sessions)}, energy={len(energy_sessions)}"
                )

            runtime_energy = runtime_sessions["energy_j"].to_numpy(float)
            energy_energy = energy_sessions["energy_j"].to_numpy(float)
            energy_ratio = float(np.median(runtime_energy) / np.median(energy_energy))
            ratio_low, ratio_high = exact_bootstrap_ratio_ci(runtime_energy, energy_energy)

            runtime_ratio = float(
                runtime_row["runtime_s_median"] / energy_row["runtime_s_median"]
            )
            energy_penalty_pct = 100.0 * (energy_ratio - 1.0)
            runtime_gain_pct = 100.0 * (1.0 - runtime_ratio)

            if runtime_config == energy_config:
                classification = "same_exact_winner"
            elif ratio_low > 1.0 + PRACTICAL_TOLERANCE:
                classification = "clear_energy_penalty_above_2pct_descriptive"
            elif ratio_low > 1.0:
                classification = "positive_energy_penalty_but_not_clear_above_2pct"
            else:
                classification = "uncertain_energy_penalty"

            rows.append({
                "platform": platform,
                "problem_size": int(size),
                "energy_opt_configuration": energy_config,
                "runtime_opt_configuration": runtime_config,
                "runtime_opt_energy_penalty_pct": energy_penalty_pct,
                "runtime_opt_over_energy_opt_energy_ratio": energy_ratio,
                "energy_ratio_ci95_low_exact": ratio_low,
                "energy_ratio_ci95_high_exact": ratio_high,
                "runtime_opt_runtime_gain_vs_energy_opt_pct": runtime_gain_pct,
                "classification_2pct": classification,
                "analysis_type": "descriptive_exact_winner_post_selection_same_five_sessions",
            })

    output = pd.DataFrame(rows).sort_values(["platform", "problem_size"])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False, float_format="%.15g")
    print(f"Wrote {len(output)} rows to {args.output}")


if __name__ == "__main__":
    main()
