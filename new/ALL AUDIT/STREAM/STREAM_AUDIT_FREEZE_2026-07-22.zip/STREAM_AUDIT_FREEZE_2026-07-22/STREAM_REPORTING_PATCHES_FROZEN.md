# STREAM Reporting Patches — Frozen

## Muss vor dem Paper geändert werden

1. **Within-Platform zweistufig berichten**
   - konservative tie-aware Leader-Set-Auswertung beibehalten;
   - zusätzlich Exact-winner-Energiestrafe als `descriptive post-selection`
     berichten.
2. **NaN korrigieren**
   - leere Leader-Schnittmenge als `none` oder `∅` rendern.
3. **Unsicherheit sichtbar machen**
   - CIs oder Stabilitätspanel in Hauptabbildungen;
   - Post-Selection-Hinweis in Captions.
4. **Intel DRAM korrigieren**
   - Sessionmedianebene: Mittel 1.805 %, Maximum 2.829 %.
5. **Cacheformulierung abschwächen**
   - `aligns with cache/working-set transitions`, nicht kausaler Beweis.
6. **Peak-Ausnutzung nicht einfrieren**
   - keine exakten CPU-Prozentwerte ohne DIMM-/Referenzmetadaten.
7. **Physischer Verkehr nicht behaupten**
   - 12N bleibt semantischer Nutzdatenanker;
   - kein exaktes 16N-Write-Allocate ohne Counter/Disassembly.

## Soll geändert werden

- alte `cpu-gpu-v1`-/42-Spalten- und RTX-5050-Projektdokumente als
  `deprecated` markieren oder aktualisieren;

- `severity` -> `severity_if_failed` in Integrity-Reports;
- Hardwaremanifest um DIMM-Bestückung, Speichertakt, Compilerflags und Source-
  Hashes ergänzen;
- Ratio-CIs optional vollständig exakt enumerieren;
- Roh-CSVs und Plattformreports ins Reproduktionsarchiv aufnehmen.

## Kein Rerun

Kein STREAM-Rerun ist für die eingefrorenen Hauptclaims notwendig.
