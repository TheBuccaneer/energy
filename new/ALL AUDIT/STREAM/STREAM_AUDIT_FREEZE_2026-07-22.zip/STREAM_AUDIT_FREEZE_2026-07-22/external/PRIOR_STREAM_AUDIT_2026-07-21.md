# Finales unabhängiges Audit — STREAM Results

**Auditdatum:** 2026-07-21  
**Gegenstand:** `results.zip` mit der kombinierten STREAM-Auswertung für Intel CPU, AMD CPU, RTX 3090 und RTX 5060 Ti.

## Gesamturteil

**PASS WITH REPORTING QUALIFICATIONS**

Die kombinierte STREAM-Auswertung ist rechnerisch und statistisch konsistent. Es wurde kein Fehler in den aggregierten Daten, der Leader-Logik, den Paarvergleichen, den Konfidenzintervallen, den Pareto-Markierungen oder den Hauptaussagen gefunden.

Es ist **kein Mess-Rerun** und **keine Änderung an den Analyseformeln** erforderlich.

Das Bundle enthält jedoch nur aggregierte Resultate, nicht die 8.100 Rohmesszeilen. Das Audit ist daher vollständig auf Sessionmedian- und Aggregatsebene, aber nicht autonom bis zu jeder Rohzeile.

## Unabhängig reproduzierte Struktur

- 810 Sessionmediane
- 162 Plattform–Größe–Konfiguration-Kombinationen
- exakt fünf Sessionmediane je Konfiguration
- 180 Native-Policy-Leader-Zeilen
- 900 ausgewählte Policy-Sessionmediane
- 270 paarweise Native-best-Vergleiche
- 45 globale Metrikgewinner
- 9 Placement-Zeilen
- keine doppelten Session-Konfigurationsschlüssel

Plattformaufteilung:

- Intel: 315 Sessionmediane = 9 Größen × 7 Threadkonfigurationen × 5 Sessions
- AMD: 405 Sessionmediane = 9 Größen × 9 Threadkonfigurationen × 5 Sessions
- RTX 3090: 45 Sessionmediane = 9 Größen × 5 Sessions
- RTX 5060 Ti: 45 Sessionmediane = 9 Größen × 5 Sessions

## Reproduzierte Metrikidentitäten

Aus den Sessionmedianen wurden unabhängig neu berechnet:

- Working Set = `12 × N`
- operationale Intensität = `2N / 12N = 1/6 FLOP/Byte`
- EDP = Laufzeit × Primärenergie
- GFLOP/s = `2N / Laufzeit / 1e9`
- GFLOP/J = `2N / Energie / 1e9`
- logische GB/s = `12N / Laufzeit / 1e9`
- logische GB/J = `12N / Energie / 1e9`

Alle Identitäten stimmen bis auf numerisches Gleitkomma-Rauschen.

`power_w` ist nicht immer exakt `energy_j/runtime_s`, weil Energie, Laufzeit und Leistung bereits pro Session separat medianisiert wurden. Die maximale relative Abweichung beträgt rund 2,01 %. Das ist erwartbare Aggregationssemantik und kein Fehler.

## Reproduzierte Statistik

Für alle 162 Konfigurationen wurden unabhängig neu berechnet:

- Median
- exaktes Bootstrap-95%-Intervall des Medians
- Session-CV

Geprüft wurden 7.128 gespeicherte Statistikwerte über elf Metriken. Alle stimmen mit den CSVs überein.

Die 270 paarweisen Native-best-Vergleiche wurden vollständig reproduziert:

- beide Mediane
- Verhältnis
- deterministisches Bootstrap-Verhältnisintervall
- Wahrscheinlichkeit, dass A besser ist
- Cliff’s Delta
- Klassifikation

Zusätzlich wurden die n=5-Bootstrap-Verhältnisintervalle als exakte diskrete Verteilungen nachgerechnet. Alle 270 gespeicherten Intervallgrenzen und alle Klassifikationen stimmen.

## Reproduzierte Entscheidungslogik

Vollständig bestätigt:

- 180/180 Native-Policy-Leader
- 45/45 globale Metrikgewinner
- 45/45 Best-CPU-vs.-Best-GPU-Vergleiche
- 9/9 Placement-Zeilen
- 162/162 strikte Pareto-Markierungen
- 162/162 praktische 2%-Pareto-Markierungen
- 162/162 Stabilitätsmarkierungen

Die inverse Kopplung ist überall korrekt:

- Runtime-Gewinner = logischer-Bandbreiten-Gewinner
- Energie-Gewinner = logischer-GB/J-Gewinner

Diese Paare dürfen nicht als unabhängige Evidenz doppelt gezählt werden.

## Zentrale wissenschaftliche Befunde

### Placement nach Größe

| N | Arbeitsmenge | Laufzeit-Leader | Energie-Leader | Einordnung |
|---:|---:|---|---|---|
| 1 Mio. | 12 MB | RTX 5060 Ti | RTX 5060 Ti | gleiche Plattform |
| 2 Mio. | 24 MB | RTX 5060 Ti | RTX 5060 Ti | gleiche Plattform |
| 4 Mio. | 48 MB | AMD CPU | RTX 5060 Ti | klarer Trade-off |
| 8 Mio. | 96 MB | AMD CPU | AMD/RTX 5060 Ti unsicher | kein klarer disjunkter Trade-off |
| 16 Mio. | 192 MB | RTX 3090 | RTX 5060 Ti | klarer Trade-off |
| 32 Mio. | 384 MB | RTX 3090 | RTX 5060 Ti | klarer Trade-off |
| 64 Mio. | 768 MB | RTX 3090 | RTX 5060 Ti | klarer Trade-off |
| 128 Mio. | 1,536 GB | RTX 3090 | RTX 5060 Ti | klarer Trade-off |
| 256 Mio. | 3,072 GB | RTX 3090 | RTX 5060 Ti | klarer Trade-off |

Damit existieren **sechs klare geräteweite fastest-vs.-greenest-Konflikte**:

- N = 4 Mio.
- N = 16, 32, 64, 128 und 256 Mio.

### Große Arbeitsmengen: RTX 3090 versus RTX 5060 Ti

Für N ≥ 16 Mio.:

- Die RTX 3090 benötigt nur etwa 46,6–47,4 % der Laufzeit der RTX 5060 Ti.
- Das entspricht ungefähr 2,11–2,15× höherer logischer Bandbreite.
- Die RTX 5060 Ti benötigt nur etwa 60,6–61,5 % der Energie der RTX 3090.
- Das entspricht ungefähr 38,5–39,4 % weniger Boardenergie.
- Trotz höherer Energie gewinnt die RTX 3090 beim EDP; ihr EDP liegt ungefähr 22–24 % niedriger.

Das ist ein starker und konsistenter Laufzeit–Energie-Trade-off zwischen den beiden GPU-Generationen.

### Cache- und Memory-Regime

Die kleinen Größen dürfen nicht pauschal als VRAM-/DRAM-bound bezeichnet werden:

- 1–2 Mio. Elemente zeigen starke Cache-Effekte, besonders auf der RTX 5060 Ti.
- 4–8 Mio. Elemente zeigen einen CPU-Cache-/Working-Set-Crossover, bei dem AMD laufzeitseitig gewinnt.
- Ab 16 Mio. Elementen stabilisiert sich das große Memory-Stress-Regime deutlich.

Die logische Bandbreite ist eine normalisierte Nutzdatenrate, kein gemessener physischer DRAM-/VRAM-Verkehr.

### CPU-Threadskalierung

Es gibt **keinen klaren tie-aware fastest-vs.-greenest-Konflikt innerhalb einer einzelnen Plattform**.

Dennoch zeigen die Punktwerte ein Sättigungsmuster:

- Intel ist bei großen N meist mit 4–8 Threads laufzeitoptimal, während 2 Threads häufig energieoptimal sind.
- AMD ist bei N ≥ 32 Mio. im Punktwert meist mit 4 Threads sowohl laufzeit- als auch energieoptimal.
- Mehr Threads liefern nach der Speicherbandbreitensättigung keinen verlässlichen Zusatznutzen.

Da sich die Leader-Sets überlappen oder mindestens eine Auswahl unsicher ist, darf daraus derzeit kein harter innerhalb-CPU-Trade-off-Claim gemacht werden.

## Stabilität

39 von 162 Konfigurationen überschreiten 5 % Session-CV bei Laufzeit oder Energie:

- AMD: 24
- Intel: 15
- GPUs: 0

30 von 180 ausgewählten Policy-Ansichten verwenden eine Konfiguration, die auf mindestens einer der beiden Primärachsen über 5 % CV liegt.

Acht globale Metrikgewinner-Zeilen basieren auf einer solchen exakten Konfiguration. Besonders zu nennen:

- AMD, N=4 Mio., 32 Threads:
  - Runtime-CV ≈ 23,95 %
  - Energie-CV ≈ 22,69 %
- AMD, N=8 Mio., 32 Threads:
  - Runtime-CV ≈ 8,99 %
  - Energie-CV ≈ 6,27 %

Die globalen Leader bleiben nach den gespeicherten Intervallen klar beziehungsweise korrekt unsicher. Trotzdem sollten Paper-Abbildungen Konfidenzintervalle zeigen oder diese Variabilität ausdrücklich nennen.

## Energiedomänen

Primär verwendet die Cross-Platform-Analyse:

- Intel: CPU-Package-RAPL
- AMD: CPU-Package-RAPL
- RTX 3090/5060 Ti: NVML-Boardenergie einschließlich Gerätespeicher

Intel besitzt zusätzlich eine DRAM-Zone. Im vorliegenden Datensatz liegt `package+DRAM` gegenüber Package-only typischerweise ungefähr 1,9–2,1 % höher, maximal etwa 2,83 %. AMD besitzt hier keine separate DRAM-Zone.

Zulässige Formulierung:

> Energieunterschiede innerhalb der jeweils gemessenen Device-Energiedomänen.

Nicht zulässig:

> vollständig gleiche Systemenergiedomänen oder Whole-System-Energie.

## GPU-Scope

Die GPU-Messungen sind `gpu_resident`:

- Daten liegen bereits im VRAM.
- Allokation und PCIe-Transfers sind ausgeschlossen.
- Die Resultate beantworten die Ausführungs- und Speicherbandbreitenfrage bei residenten Daten.

Für eine reale Placement-Entscheidung mit ursprünglich im Hostspeicher liegenden Daten wäre eine getrennte transferinklusive Sensitivitätsmessung notwendig. Das ist keine Ungültigkeit der vorliegenden Kampagne, sondern eine Scope-Grenze.

## Reporting-Probleme ohne Einfluss auf die Berechnung

1. Leere Runtime-/Energy-Leader-Schnittmengen werden nach dem CSV-Reload als `NaN` dargestellt. Inhaltlich bedeutet dies „keine Überlappung“. Das ist kosmetisch und sollte im Bericht als leer beziehungsweise `none` ausgegeben werden.
2. Die aktuellen Hauptfiguren zeigen Medianlinien ohne Konfidenzintervalle. Für die Publikation sollten Intervalle oder ein ergänzendes Stabilitätspanel verwendet werden.
3. Das Result-Bundle enthält keine 8.100 Rohzeilen und keine individuellen Plattformresultate. Für ein autonomes Reproduktionsarchiv sollten Roh-CSVs, Validierungsreports, Source-/Runner-Hashes und Kampagnenmanifeste ergänzt werden.

## Zulässige Hauptclaims

1. STREAM zeigt größenabhängige Placement-Crossover zwischen CPU und GPU.
2. Kleine und mittlere Working Sets sind cachebeeinflusst; das große Memory-Regime beginnt in diesen Daten ab ungefähr N=16 Mio.
3. Bei großen residenten Working Sets ist die RTX 3090 klar laufzeitoptimal, während die RTX 5060 Ti klar energieoptimal ist.
4. Die RTX 3090 liefert im großen Regime ungefähr 2,1× höhere logische Bandbreite, während die RTX 5060 Ti ungefähr 39 % weniger Boardenergie verbraucht.
5. Es gibt sechs klare geräteweite fastest-vs.-greenest-Konflikte.
6. Innerhalb der CPU-Plattformen zeigt sich Bandbreitensättigung, aber kein statistisch klarer tie-aware fastest-vs.-greenest-Konflikt.
7. Alle Energieclaims gelten nur innerhalb der gemessenen Energiedomänen und für den residenten GPU-Modus.

## Nicht zulässige Claims

- `12N` sei gemessener physischer Speicherverkehr.
- GPU-Resultate enthielten PCIe-Transferkosten.
- CPU-Package-RAPL und GPU-Board-NVML seien identische Energiedomänen.
- 50 technische Wiederholungen seien 50 unabhängige Stichproben.
- die Native-best-Schätzungen seien konfirmatorische Hardwarepopulation-Inferenz.
- jede getestete Größe sei gleichermaßen DRAM-/VRAM-bound.
- innerhalb einer CPU-Plattform sei ein klarer fastest-vs.-greenest-Konflikt bewiesen.

## Endurteil

**Die STREAM-Auswertung ist für die deskriptive Cross-Platform-Analyse freigegeben.**

Keine Analyseformel, keine Klassifikation und keine Messkampagne muss aufgrund dieses Audits wiederholt werden. Vor dem Paper-Schreiben sind nur die genannten Reporting- und Scope-Qualifikationen einzuarbeiten.
