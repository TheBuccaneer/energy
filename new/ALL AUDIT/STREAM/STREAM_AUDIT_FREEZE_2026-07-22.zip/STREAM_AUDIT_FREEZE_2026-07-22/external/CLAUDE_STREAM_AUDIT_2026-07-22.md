Ich habe im vorigen Durchgang bereits die Struktur, die Placement-Tabelle, die GPU-Ratios, die Stabilität und die N=8M-Unsicherheit unabhängig nachgerechnet. Was noch fehlt: der Messcode (03), der komplette Analysecode (04) und die exakte Reproduktion der Bootstrap-Intervalle, Pareto- und Pairwise-Logik. Das hole ich jetzt nach.Jetzt die entscheidenden statistischen Funktionen im Detail — Bootstrap, Cliff's Delta, Klassifikation, Leader-Logik, Pareto.Der Bootstrap ist der kritische Punkt. Ich prüfe die Konstanten und reproduziere dann die gespeicherten Intervalle exakt nach.Jetzt die vollständige Reproduktion: exakte n=5-Bootstrap-CIs (5⁵=3125 Enumeration) über alle Konfigurationen und Metriken, plus die 270 Pairwise-Zeilen mit der seed-deterministischen Ratio-Bootstrap.Alle 7.128 Statistikwerte stimmen exakt. Jetzt die 270 Pairwise-Vergleiche inklusive seed-deterministischer CIs und Cliff's Delta.Alle 270 Pairwise-Zeilen reproduzieren exakt, inklusive der seed-deterministischen CIs. Jetzt die verbleibenden Entscheidungstabellen: Pareto, Leader, Winner, Best-CPU-vs-GPU, Within-Platform-Tradeoffs.Ein wichtiger Befund in der Within-Platform-Tabelle: Intel zeigt bei 32M–128M **disjunkte** Leader-Sets und Energie-Aufschläge bis ~50 %. Das prüfe ich statistisch nach, weil die Aussage „kein Within-Platform-Konflikt" davon abhängt.Das ist ein substanzieller Befund. Ich präzisiere ihn und prüfe dann den Messcode.Jetzt der Messcode — Messfenster, Threadguard, NVML-Bindung, Checksum-Position.Ein Plausibilitätscheck, den das Vor-Audit nicht gemacht hat: Liegen die logischen Bandbreiten physikalisch im erwartbaren Bereich der jeweiligen Hardware?Die Bandbreiten liefern eine mechanistische Erklärung der Regime. Ich verifiziere die Cache-Hypothese quantitativ und sehe mir das GPU-Messfenster an.Zum Abschluss die Cache-Hypothese quantitativ und ein Blick auf den generierten Ergebnisbericht.Ich habe alles nachgerechnet, was das Bundle hergibt. Hier das Audit im geforderten Format.

# STREAM Audit — Unabhängige Gegenprüfung

## 1. Overall verdict

**`ACCEPT WITH REPORTING PATCHES`**

```text
Measurement campaign:    gültig — kein Rerun erforderlich
Analysis implementation: exakt, deterministisch, korrekt — keine Formeländerung erforderlich
Aggregate results:       vollständig reproduziert (7.128 Statistikwerte, 270 Pairwise, 162 Pareto — 0 Abweichungen)
Publication claims:      überwiegend gedeckt; zwei müssen verstärkt, drei präzisiert werden
```

Ich bestätige das Vor-Audit rechnerisch in vollem Umfang, widerspreche ihm aber in zwei inhaltlichen Punkten: Es hat (a) die erreichte Bandbreitenausnutzung nie gegen die Hardwarespezifikation geprüft und (b) den Within-Platform-Befund zu schwach dargestellt. Beides sind Reporting-Patches, keine Defekte.

## 2. Reproduction table

| Claim | Unabhängig neu berechnet | Gespeichert | Match | Wissenschaftliche Einordnung |
|---|---|---|---|---|
| 810 Sessionmediane, 162 Konfig., exakt 5 Sessions | 810 / 162 / alle=5 | identisch | ✅ | Struktur korrekt |
| Plattformsplit 315/405/45/45 | identisch | identisch | ✅ | Designtreue |
| `working_set = 12N`, `OI = 1/6` | exakt | exakt | ✅ | Semantikanker konsistent |
| Alle Konfig-Mediane, exakte n=5-Bootstrap-CIs, Session-CVs (11 Metriken) | 7.128 Werte, max. Abw. 8,4e-15 | identisch | ✅ | Statistik exakt reproduzierbar |
| 270 Pairwise: Mediane, Ratio, CI, P(A besser), Cliff's δ, Klassifikation | 270/270 in **allen fünf** Feldern | identisch | ✅ | Seed-deterministisch nachvollzogen |
| Strict-Pareto / Practical-2%-Pareto | 162/162, Front je 16 Konfig. | identisch | ✅ | Pareto-Logik korrekt |
| 39 instabile Konfig. (24 AMD, 15 Intel, 0 GPU) | 39 (24/15/0) | 39 | ✅ | GPUs außergewöhnlich stabil (CV ≤0,7 %) |
| AMD 4M/8M 32T CV | 23,95 %/22,69 % bzw. 8,99 %/6,27 % | identisch | ✅ | Muss in Abbildungen sichtbar sein |
| Sechs klare fastest-vs-greenest-Konflikte | 4M, 16M, 32M, 64M, 128M, 256M = **6** | 6 | ✅ | Kernbefund bestätigt |
| N=8M Energie AMD vs 5060 Ti | Ratio-CI **0,909–1,064**, P=0,941 | tie_or_uncertain | ✅ | Korrekt als unsicher geführt |
| N=4M Energie AMD vs 5060 Ti | Ratio-CI **1,127–1,139** | clear_5060ti | ✅ | Klar, kein Tie |
| 3090 Laufzeitanteil ggü. 5060 Ti (N≥16M) | **0,4662–0,4736** | 46,6–47,4 % | ✅ | Exakt |
| 3090 logische Bandbreite (N≥16M) | **2,111–2,145×** | ≈2,1× | ✅ | Exakt |
| 5060 Ti Boardenergie-Ersparnis | **38,5–39,3 %** | 38,5–39,4 % | ✅ | Marginal enger als angegeben |
| 3090 EDP-Vorteil | **22,0–24,2 %** | 22–24 % | ✅ | Exakt |
| `power_w ≠ energy/runtime` | max. **2,0071 %** | ≈2,01 % | ✅ | Aggregationssemantik, kein Fehler |
| Intel `package+DRAM` vs `package` | Mittel **1,81 %**, max **2,83 %** | 1,9–2,1 %, max 2,83 % | ⚠️ | Mittelwert leicht überschätzt (1,81 statt 1,9–2,1) |
| „Kein Within-Platform-Konflikt" | Formal ja — **inhaltlich irreführend** | no_tie_aware_conflict | ⚠️ | Siehe §7, wichtigster Reporting-Patch |
| Bandbreitenausnutzung CPU vs GPU | CPU **31–44 %**, GPU **88–91 %** des Peaks | *nicht geprüft* | ❌ neu | Fehlt vollständig, interpretationsrelevant |

## 3. Code audit

**Blockers:** keine.

**Required patches (Reporting, kein Code):**

1. **Erreichte Bandbreitenausnutzung offenlegen.** Bei N=256M erreicht die 3090 848,9 GB/s (≈91 % ihres 936-GB/s-Peaks) und die 5060 Ti 395,8 GB/s (≈88 % von 448), während Intel 26,5 GB/s (≈31 % von ≈85) und AMD 41,8 GB/s (≈44 % von ≈102) erreichen. Selbst mit Write-Allocate-Korrektur (physisch 16N statt 12N) kommen die CPUs nur auf ≈41 % bzw. ≈59 %. Der CPU-Triad nutzt keine Non-Temporal Stores; ein Teil des CPU-Rückstands ist damit Implementierungs-, nicht Hardwareeigenschaft. Das invalidiert nichts (der Vertrag verlangt plattformnative Implementierungen), muss aber im Paper stehen, sonst liest sich der CPU/GPU-Abstand als reine Hardwareaussage.
2. **Asymmetrie des 12N-Ankers benennen.** Da die GPUs bei ~90 % des Peaks liegen, kann ihr physischer Verkehr nicht 16N betragen (das wäre >100 % des Peaks) — sie vermeiden Write-Allocate. Die CPUs tun das mit hoher Wahrscheinlichkeit nicht. Derselbe semantische 12N-Anker entspricht also plattformabhängig unterschiedlichem Physikverkehr.
3. **Within-Platform-Befund korrekt darstellen** (siehe §7, Punkt 1).
4. **`NaN`-Überlappung als `none`/∅ rendern** (bestätigt kosmetisch, betrifft Intel 32M/64M/128M und 4M/16M/32M/… im Placement).
5. **Post-Selection-Charakter der Pairwise-Intervalle in die Bildunterschriften**, nicht nur ins Methodenkapitel. Das CSV führt das Label `descriptive_native_best_post_selection_independent_sessions` bereits vorbildlich mit.

**Optional improvements:**

- `exact_bootstrap_median` enumeriert 5⁵=3125 Resamples exakt; `bootstrap_ratio_ci` nutzt 20.000 gezogene Draws. Für n=5 wäre auch das Ratio-Intervall exakt enumerierbar (3125×3125) — würde die letzte Monte-Carlo-Restunsicherheit beseitigen. Praktisch irrelevant, aber „exakt" wäre dann wörtlich korrekt.
- `17_integrity_checks.csv` führt `severity=FAIL` bei `status=PASS`; die Spalte meint offenbar „Schweregrad *falls* fehlschlagend". Umbenennen in `severity_if_failed`.
- Cliff's δ und `probability_a_better` haben bei n=5 eine Auflösung von 1/25 = 0,04. Als deskriptive Effektstärke in Ordnung, aber nicht feiner interpretieren.

**False alarms — dürfen keinen Rerun auslösen:**

- `power_w ≠ energy_j/runtime_s` (max. 2,0071 %): korrekte Folge getrennter Medianbildung.
- CUDA-Event minimal > Host-E2E: getrennte Taktdomänen; die Regel `max(0,5 ms; 0,5 % E2E)` ist richtig.
- `NaN` bei leerer Leader-Überlappung: leere Menge, kein fehlender Wert.
- AMD-Serialisierungsrundung: Validatorfehler, war korrekt gefixt.
- Fehlende Rohzeilen/`benchmark_common.hpp`: Bundle-Grenze, kein Messmangel.

**Messcode-Prüfung (Fragenblock B):** Initialisierung, Kalibrierung, Allokation und Checksum liegen außerhalb des Fensters ✓. CPU-Threadguard prüft `omp_get_num_threads()` im Parallelbereich und schreibt den beobachteten Wert ✓. GPU-NVML über `nvmlDeviceGetHandleByPciBusId_v2` statt Index ✓. Fensterschachtelung `Telemetrie → Energie → Wall → Event → Enqueue → Event → Sync → Wall → Energie → Telemetrie → Checksum` ist konsistent ✓. Batch-Elision ist strukturell ausgeschlossen (jeder Batch ist ein eigenes `omp for`-Konstrukt mit impliziter Barriere bzw. ein eigener Kernel-Launch), und die physikalisch plausiblen Bandbreiten bestätigen das empirisch ✓.

## 4. Statistical audit

**Experimentaleinheit.** Korrekt: 10 technische Wiederholungen → 1 Sessionmedian → n=5 Sessionmediane je Konfiguration. Nirgends wird n=50 behauptet. Die Einheit ist die Session, nicht die Wiederholung.

**Bootstrap/CI-Validität.** `exact_bootstrap_median` enumeriert alle 5⁵ Indexkombinationen — exakt und deterministisch, kein Seed nötig. **Wichtige Eigenschaft, die im Paper stehen sollte:** Der Median eines 5-elementigen Resamples ist stets einer der fünf Originalwerte. Die Bootstrap-Verteilung hat damit höchstens fünf Träger, und die 2,5-/97,5-%-Grenzen liegen praktisch immer bei der zweitkleinsten bzw. zweitgrößten Beobachtung. Diese Intervalle sind also grobe, diskrete Objekte und keine glatten 95-%-Intervalle; ihre Überdeckung ist approximativ. Für Entscheidungen ist das unproblematisch, weil das Kriterium ohnehin konservativ ist — es darf nur nicht als präzise Unsicherheitsquantifizierung verkauft werden.

**Selektionseffekte.** Die Native-best-Auswahl und die berichteten Intervalle nutzen dieselben fünf Sessions. Die Pipeline deklariert das korrekt als deskriptiv. Meine eigenen Within-Platform-Tests (§7) haben dieselbe Einschränkung; bei Effekten von 43–50 % ist sie unkritisch, bei 6–9 % zählt sie.

**Stabilität.** 39/162 Konfigurationen >5 % CV, ausschließlich CPU (24 AMD, 15 Intel). GPU-CVs liegen bei ≤0,7 % — bemerkenswert und selbst ein Befund. Die Instabilität konzentriert sich auf kleine N und hohe Threadzahlen (AMD 8M: 5 von 9 Konfigurationen instabil).

**Pareto-Logik.** Strikt: dominiert, wenn ein anderer Punkt in beiden Achsen ≤ und in einer < ist. Praktisch: dominiert, wenn ein anderer Punkt beide Achsen um Faktor 1/1,02 unterbietet. Beide reproduziert (162/162), beide Fronten umfassen 16 Konfigurationen.

**Pairwise-Logik.** `classify_ratio` mit 2-%-Äquivalenzband und CI-Lage; `select_leaders` erklärt einen Leader nur dann als „clear", wenn er eindeutig ist, >2 % Abstand zum Zweiten hat **und** sein CI von allen anderen getrennt ist. Konservativ und korrekt — mit der in §7 beschriebenen Nebenwirkung.

## 5. Final placement map

| N | Working Set | Runtime-Leader | Energie-Leader | EDP-Leader | Status | Trade-off-Klassifikation |
|---:|---:|---|---|---|---|---|
| 1M | 12 MB | RTX 5060 Ti | RTX 5060 Ti | RTX 5060 Ti | alle clear | kein Konflikt (Cache-Regime, 5060-Ti-L2) |
| 2M | 24 MB | RTX 5060 Ti | RTX 5060 Ti | RTX 5060 Ti | alle clear | kein Konflikt (Cache-Regime) |
| 4M | 48 MB | AMD | RTX 5060 Ti | AMD | alle clear | **klarer Konflikt** |
| 8M | 96 MB | AMD | AMD *(Set: AMD, 5060 Ti)* | AMD | Energie **unsicher** | kein disjunkter Konflikt |
| 16M | 192 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | alle clear | **klarer Konflikt** |
| 32M | 384 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | alle clear | **klarer Konflikt** |
| 64M | 768 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | alle clear | **klarer Konflikt** |
| 128M | 1,536 GB | RTX 3090 | RTX 5060 Ti | RTX 3090 | alle clear | **klarer Konflikt** |
| 256M | 3,072 GB | RTX 3090 | RTX 5060 Ti | RTX 3090 | alle clear | **klarer Konflikt** |

**Mechanistische Erklärung — vom Vor-Audit nur qualitativ, hier quantitativ belegt.** Jeder Regimewechsel fällt exakt mit einer Last-Level-Cache-Grenze zusammen:

| Plattform | LLC | Working Set passt bis | Beobachtete logische Bandbreite |
|---|---|---|---|
| RTX 5060 Ti | 32 MB L2 | 2M (24 MB) | 1466/1675 GB/s → **502** GB/s ab 4M |
| AMD 3970X | 128 MB L3 | 8M (96 MB) | 1109/1144 GB/s → **54** GB/s ab 16M |
| Intel 7900X | 13,75 MB L3 | 1M (12 MB) | 230 GB/s → **99/37** GB/s ab 2M/4M |
| RTX 3090 | 6 MB L2 | — | flach 760–849 GB/s über alle N |

Damit ist die AMD-Führung bei 4M/8M kein Zufall, sondern die direkte Folge des 128-MB-L3 des Threadrippers, und der Übergang ins stabile Memory-Regime bei N≥16M ist präzise dadurch erklärt, dass ab dort **keine** Plattform mehr im Cache liegt. Das ist die stärkste verfügbare Stützung der Regime-These und gehört ins Paper.

## 6. Allowed paper claims

Publikationsreife, vollständig gedeckte Formulierungen:

> Across nine problem sizes, the runtime-, energy- and EDP-optimal hardware placement for a bandwidth-bound FP32 Triad diverges at six of nine sizes, demonstrating that the optimization objective — not the workload alone — determines the correct device.

> For resident working sets of 192 MB and above, the RTX 3090 sustains 2.11–2.15× the logical useful-data rate of the RTX 5060 Ti, while the RTX 5060 Ti consumes 38.5–39.3 % less board energy; the RTX 3090 nevertheless attains a 22.0–24.2 % lower energy-delay product. Race-to-idle therefore holds under an EDP objective but is reversed under a pure energy objective.

> Every observed placement crossover coincides with a last-level-cache boundary: the AMD Threadripper 3970X leads on runtime at 4M and 8M elements, where the 48 MB and 96 MB working sets fit its 128 MB L3, and loses that lead at 16M (192 MB), where its logical bandwidth falls from 1144 GB/s to 54 GB/s.

> At 8M elements the energy-optimal platform cannot be resolved: the bootstrap ratio interval between the AMD CPU and the RTX 5060 Ti is 0.909–1.064 and therefore contains unity.

> Statistical unit is the session median; five sessions per configuration were analysed with exact enumeration-based bootstrap intervals. GPU configurations were markedly more reproducible than CPU configurations (0 of 18 versus 39 of 144 configurations exceeding 5 % session coefficient of variation).

> All energy statements refer to the respective measured device domains — CPU package RAPL and NVML board energy including device memory — which are not equivalent whole-system boundaries.

> On the Intel platform, selecting the runtime-optimal thread count instead of the energy-optimal one costs a statistically clear energy premium at five of nine sizes, reaching 50.3 % at 256M elements for a 0.6 % runtime gain over the best compromise configuration.

## 7. Claims to forbid or weaken

**1. Wichtigster Punkt — die Within-Platform-Aussage ist zu schwach und dadurch irreführend.**

> ❌ Unsicher: „Es gibt keinen klaren tie-aware fastest-vs.-greenest-Konflikt innerhalb einer einzelnen Plattform." / „Innerhalb der CPU-Plattformen zeigt sich Bandbreitensättigung, aber kein statistisch klarer Konflikt."

Formal stimmt das für das gewählte Kriterium (disjunkte Leader-Sets **und** beide Selektionen „clear"). Inhaltlich ist es aber ein Artefakt der breiten Runtime-Leader-Sets bei n=5 — nicht die Abwesenheit eines Trade-offs. Direkt getestet (Energieverhältnis der runtime-optimalen zur energieoptimalen Threadzahl, exaktes Bootstrap) ergibt sich auf Intel:

| N | en-opt | rt-opt | Energieaufschlag | Ratio-CI95 | klar? |
|---:|---|---|---:|---|---|
| 4M | 2T | 10T | **+49,0 %** | 1,389–1,599 | ✅ |
| 8M | 2T | 8T | **+42,9 %** | 1,311–1,618 | ✅ |
| 16M | 2T | 4T | +6,4 % | 1,012–1,192 | ✗ |
| 32M | 2T | 4T | **+6,9 %** | 1,045–1,145 | ✅ |
| 64M | 2T | 4T | **+8,3 %** | 1,059–1,228 | ✅ |
| 128M | 2T | 4T | +8,7 % | 1,009–1,115 | ✗ |
| 256M | 2T | 8T | **+50,3 %** | 1,367–1,544 | ✅ |

Auf AMD dagegen fallen beide Optima ab 32M auf dieselbe Konfiguration (4T) zusammen — Aufschlag 0,0 %. Das ist ein **plattformabhängiger** Befund, kein Nullbefund.

> ✅ Korrigiert: „Within the Intel platform, the runtime- and energy-optimal thread counts differ at seven of nine sizes, and the energy premium of the runtime-optimal choice is statistically clear at five sizes (6.9 %–50.3 %). The conservative tie-aware leader-set criterion does not label these as conflicts because a compromise thread count exists that belongs to both leader sets: at 256M elements, 4 threads are within 0.63 % of the best runtime while consuming 40.9 percentage points less excess energy than the exact runtime winner. On AMD, both objectives converge on 4 threads for N ≥ 32M. Thread-count selection is therefore objective-dependent on Intel and objective-neutral on AMD in this regime."

Das beantwortet direkt Studienfrage 4 („Welche Strafe folgt aus der Optimierung auf das falsche Ziel?") und ist derzeit der am stärksten unterberichtete Befund des Bundles.

**2. Bandbreitenvergleich ohne Ausnutzungskontext.**

> ❌ „Die RTX 3090 liefert ungefähr 2,1× höhere logische Bandbreite."
> ✅ „…2.11–2.15× the logical useful-data rate of the RTX 5060 Ti. Both GPUs operate near their nominal peak (≈91 % and ≈88 %), whereas both CPU implementations reach only ≈31 % (Intel) and ≈44 % (AMD) of nominal peak memory bandwidth; the CPU kernel uses ordinary stores and therefore additionally incurs write-allocate traffic. CPU-versus-GPU ratios thus compare as-implemented platform-native code, not peak-versus-peak capability."

**3. Regime-Grenze als scharfe Schwelle.**

> ❌ „das große Memory-Regime beginnt ab N=16 Mio."
> ✅ „In diesem Hardwareset liegt ab N=16M keine Plattform mehr im LLC; die Grenze ist hardwarespezifisch (5060 Ti ab 4M, Intel ab 2M, AMD ab 16M) und keine universelle Schwelle."

**4. Intel-DRAM-Sensitivität.**

> ❌ „typischerweise ungefähr 1,9–2,1 % höher"
> ✅ „im Mittel 1,81 %, maximal 2,83 %" (nachgerechnet).

**5. Weiterhin verboten** (vom Bundle korrekt gelistet, hier bestätigt): 12N als gemessener Physikverkehr; PCIe-inklusive Placement-Aussagen; Package-RAPL ≙ Board-NVML; fünf Sessions als Hardwarepopulations-Inferenz; Laufzeit **und** logische Bandbreite bzw. Energie **und** logische GB/J als unabhängige Evidenz — die Integritätsprüfung bestätigt exakte inverse Kopplung (0 Abweichungen); EDP als eigenständige Messgröße.

## 8. Residual limitations

**Grenzen des Experiments:**
- CPU-Kernel ohne Non-Temporal Stores; CPUs erreichen 31–44 % des nominellen Peaks, GPUs 88–91 %. Interpretationsrelevant.
- Auffällig: Auf Intel ist bei großen N bereits 4T laufzeitoptimal, 20T ist langsamer — untypisch für ein 10-Kern-Quad-Channel-System und möglicherweise ein Hinweis auf die DIMM-/Kanalbestückung, die im Bundle nicht dokumentiert ist.
- `gpu_resident`: keine PCIe-Kosten; für Host-residente Daten nicht übertragbar.
- Energiedomänen asymmetrisch (Package ohne DRAM vs. Board mit VRAM) — bei einem bandbreitengebundenen Workload zugunsten der CPU verzerrend.
- n=5 Sessions, eine Maschine je Typ: deskriptiv, nicht populationsinferenziell.
- 39 instabile CPU-Konfigurationen, davon 8 als exakte globale Metrikgewinner verwendet.

**Grenzen dieses 20-Datei-Bundles:**
- 8.100 Rohzeilen fehlen → einzelne Checksummen, Rohzeilen-Formelidentitäten, Kalibrierverhalten und Batchzahlen nicht direkt prüfbar (indirekt über Code, Integritätsgates und physikalische Plausibilität bestätigt).
- `benchmark_common.hpp` fehlt → RAPL-Interna und Writer-Rundung nicht quellauditierbar.
- Nur repräsentative Runner; Intel-/5060-Ti-Analoga nur über Hashes belegt.
- DIMM-Konfiguration und Compiler-Flags nicht dokumentiert → meine Peak-Bezugswerte sind Nominalwerte, keine gemessenen Maschinenmaxima.

**Was neue Messungen erfordern würde (nicht für dieses Paper zwingend):**
- Referenz-STREAM-Lauf (McCalpin bzw. Non-Temporal-Variante) zur Einordnung der CPU-Bandbreitenausnutzung.
- Transferinklusive GPU-Sensitivität für Host-residentes Placement.
- Package+DRAM auf AMD (im Datensatz nicht verfügbar) für symmetrische Energiegrenzen.

## 9. Final action list

```text
MUST CHANGE BEFORE PAPER
1. Within-Platform-Aussage nach §7.1 umformulieren — derzeit unterberichteter Kernbefund
   (Intel: 6,9-50,3 % Energieaufschlag, klar bei 5/9 Größen; AMD: konvergent)
2. Bandbreitenausnutzung offenlegen (CPU 31-44 % vs GPU 88-91 % des Peaks)
   und CPU-Kernel ohne Non-Temporal Stores benennen
3. Cache-Mechanik als Erklärung der Regimewechsel aufnehmen (LLC-Tabelle §5)
4. NaN-Leader-Überlappung als none/∅ rendern
5. Post-Selection-Charakter der Native-best-Intervalle in Bildunterschriften
6. Intel-DRAM-Sensitivität auf 1,81 % Mittel / 2,83 % Max korrigieren

SHOULD CHANGE
7. Konfidenzintervalle oder Stabilitätspanel in die Hauptabbildungen
8. n=5-Bootstrap-Granularität im Methodenteil benennen (CI-Grenzen sind Ordnungsstatistiken)
9. severity-Spalte in integrity_checks.csv umbenennen
10. Ratio-CIs exakt enumerieren statt 20.000 Draws (Kosmetik)
11. Reproduktionsarchiv um Rohzeilen, DIMM-/Compiler-Metadaten, Hashes ergänzen

NO CHANGE / NO RERUN
12. Messkampagne — keine Wiederholung erforderlich
13. Alle Analyseformeln, Leader-, Pareto-, Pairwise- und Klassifikationslogik
14. power_w-Abweichung, CUDA-Event-Kreuzung, AMD-Rundung: bestätigte False Alarms
15. Placement-Tabelle, sechs Konflikte, GPU-Ratios, Stabilitätszählung: exakt reproduziert
```

**Zur „So what?"-Frage:** STREAM trägt mehr als ein Hardware-Ranking, aber nicht wegen „CPU vs. GPU". Der publikationsfähige Kern ist, dass die Studie zwei *unabhängige* Achsen der Zielabhängigkeit demonstriert — zwischen Geräten (sechs Konflikte, davon fünf im stabilen Memory-Regime mit klarem 3090/5060-Ti-Split) **und**, nach der Korrektur aus §7.1, innerhalb einer Plattform über die Threadzahl, wo dieselbe Hardware je nach Ziel unterschiedlich konfiguriert werden muss und die Fehlwahl bis zu 50 % Energie kostet. Dass beide Achsen an Cache-Grenzen umschlagen, macht daraus eine Regime-Aussage statt einer Rangliste. Kombiniert mit GEMM (compute-gebunden) und STRIDED_GEMM (Layout-Störung) ergibt das die belastbare Formulierung: *Optimierungsziel und Working-Set-Regime bestimmen gemeinsam die richtige Platzierung; Race-to-idle ist ein Regime, keine universelle Regel.* Ohne die beiden Reporting-Patches oben wäre diese Aussage für STREAM allein nur zur Hälfte belegt.