# Finales eingefrorenes STREAM-Audit

**Auditdatum:** 2026-07-22  
**Status:** `PASS / ACCEPT WITH REPORTING PATCHES`  
**Plattformen:** Intel i9-7900X, AMD Threadripper 3970X, RTX 3090, RTX 5060 Ti  
**Scope:** STREAM Triad, `gpu_resident`, fünf Sessions je Konfiguration

## 1. Evidenz und Provenienz

Dieses Abschlussaudit konsolidiert:

- das erste unabhängige STREAM-Audit;
- das kompakte 20-Dateien-Reproduktionsbundle;
- die unabhängige Claude-Gegenprüfung;
- eine zusätzliche lokale Gegenprüfung der neuen Within-Platform-Aussage.

SHA-256:

```text
802070e29fda3b054847b6ed74a89ec544364869ba88d7b6c87531fe6efef056  STREAM_CLAUDE_AUDIT_BUNDLE_20_FILES.zip
adfb16acfff3d94d6085a63cb67de7b5aec746f9d19f5c07eb2de7b64851f3d4  Finales_Audit_STREAM_Results_2026-07-21.md
0ce231846f3af40b16669a9071f4b7daa2b037811c9576225f4916bc55b5baca  Claude-Gegenprüfung (Pasted markdown(10).md)
```

Die Claude-Gegenprüfung reproduziert alle im Bundle prüfbaren Aggregationen und
kommt ebenfalls zu `ACCEPT WITH REPORTING PATCHES`. Sie bestätigt insbesondere
7.128 Konfigurationsstatistiken, 270 Pairwise-Vergleiche, 162 Pareto-Zeilen,
die Placement-Tabelle und die Stabilitätszählung.

## 2. Endurteil

```text
Messkampagne:         PASS — kein Rerun erforderlich
Analyseimplementation: PASS — keine Formel- oder Klassifikationsänderung
Aggregierte Resultate: PASS — vollständig reproduziert
Publikationsclaims:    PASS WITH REPORTING PATCHES
```

Es wurde kein Mess-, Aggregations-, Bootstrap-, Pairwise-, Pareto- oder
Placement-Fehler gefunden, der einen erneuten STREAM-Lauf erfordert.

## 3. Eingefrorener Mess- und Analysevertrag

STREAM berechnet semantisch:

```text
a[i] = b[i] + 3.0f * c[i]
```

pro Operation:

```text
FLOPs         = 2N
logische Bytes = 12N
```

Die 12N Byte sind ein semantischer Nutzdatenanker und kein gemessener
physischer DRAM-/VRAM-Verkehr.

Statistische Einheit:

```text
10 technische Wiederholungen
-> ein Sessionmedian
-> fünf Sessionmediane je Konfiguration
```

Die fünfzig Rohmessungen je Konfiguration dürfen nicht als fünfzig unabhängige
Beobachtungen dargestellt werden.

## 4. Vollständig reproduzierte Struktur

- 810 Sessionmediane;
- 162 Konfigurationen;
- exakt fünf Sessions je Konfiguration;
- Intel 315, AMD 405, RTX 3090 45, RTX 5060 Ti 45 Sessionmediane;
- 180 Native-Policy-Leader;
- 900 ausgewählte Policy-Sessionmediane;
- 270 paarweise Native-best-Vergleiche;
- 45 globale Metrikgewinner;
- neun Placement-Zeilen;
- 162 strikte und 162 praktische Pareto-Markierungen.

Alle 7.128 gespeicherten Konfigurationsstatistiken wurden ohne relevante
Abweichung reproduziert.

## 5. Eingefrorene Placement-Ergebnisse

| N | Working Set | Laufzeit-Leader | Energie-Leader | EDP-Leader | Einordnung |
|---:|---:|---|---|---|---|
| 1M | 12 MB | RTX 5060 Ti | RTX 5060 Ti | RTX 5060 Ti | kein Konflikt |
| 2M | 24 MB | RTX 5060 Ti | RTX 5060 Ti | RTX 5060 Ti | kein Konflikt |
| 4M | 48 MB | AMD | RTX 5060 Ti | AMD | klarer Konflikt |
| 8M | 96 MB | AMD | AMD / RTX 5060 Ti unsicher | AMD | Energie nicht auflösbar |
| 16M | 192 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | klarer Konflikt |
| 32M | 384 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | klarer Konflikt |
| 64M | 768 MB | RTX 3090 | RTX 5060 Ti | RTX 3090 | klarer Konflikt |
| 128M | 1.536 GB | RTX 3090 | RTX 5060 Ti | RTX 3090 | klarer Konflikt |
| 256M | 3.072 GB | RTX 3090 | RTX 5060 Ti | RTX 3090 | klarer Konflikt |

Damit sind sechs klare geräteweite Fastest-versus-Greenest-Konflikte
reproduziert:

```text
4M, 16M, 32M, 64M, 128M, 256M
```

## 6. Eingefrorener großer GPU-Regime-Befund

Für `N >= 16M`:

- RTX 3090 Laufzeitanteil gegenüber RTX 5060 Ti: `0.4662–0.4736`;
- logische Nutzdatenrate der RTX 3090: `2.111–2.145x`;
- Boardenergieersparnis der RTX 5060 Ti: `38.5–39.3 %`;
- EDP-Vorteil der RTX 3090: `22.0–24.2 %`.

Zulässige Interpretation:

> Im residenten großen STREAM-Regime gewinnt die RTX 3090 bei Laufzeit und
> EDP, während die RTX 5060 Ti innerhalb ihrer gemessenen Boardenergiedomäne
> die geringere Energie-to-Solution aufweist.

## 7. Ergänzter Within-Platform-Befund

### 7.1 Zwei unterschiedliche Fragen dürfen nicht vermischt werden

Die bestehende Leader-Set-Auswertung ist korrekt:

> Es gibt keinen vollständig klaren tie-aware Within-Platform-Konflikt, bei dem
> die Laufzeit- und Energie-Leader-Sets disjunkt sind und beide Auswahlen als
> eindeutig klassifiziert werden.

Die Claude-Gegenprüfung untersucht zusätzlich eine andere Frage:

> Wie hoch ist die Energie-Strafe des exakten Laufzeit-Punktgewinners gegenüber
> dem exakten Energie-Punktgewinner?

Diese zweite Auswertung ist sinnvoll, aber **deskriptiv und post-selection**,
weil beide Konfigurationen anhand derselben fünf Sessions ausgewählt und
verglichen werden. Sie ersetzt die konservative Leader-Set-Aussage nicht,
sondern ergänzt sie.

### 7.2 Reproduzierter Intel-Befund

| N | Energieoptimum | Laufzeitoptimum | Energieaufschlag | exaktes Ratio-CI | klare >2%-Strafe? |
|---:|---:|---:|---:|---:|---|
| 4M | 2T | 10T | 49.0 % | 1.389–1.599 | ja |
| 8M | 2T | 8T | 42.9 % | 1.311–1.618 | ja |
| 16M | 2T | 4T | 6.4 % | 1.012–1.192 | nein |
| 32M | 2T | 4T | 6.9 % | 1.045–1.145 | ja |
| 64M | 2T | 4T | 8.3 % | 1.059–1.228 | ja |
| 128M | 2T | 4T | 8.7 % | 1.009–1.115 | nein |
| 256M | 2T | 8T | 50.3 % | 1.367–1.544 | ja |

Die 2%-Klassifikation ist bei fünf Größen klar. Im Paper muss sie als
`descriptive exact-winner post-selection analysis` bezeichnet werden.

Besonders bei 256M darf nicht nur der extreme Punktvergleich stehen:

- 8T ist der exakte Laufzeitgewinner und verbraucht 50.3 % mehr Energie als 2T;
- 4T ist nur 0.63 % langsamer als 8T, verbraucht aber lediglich 9.35 % mehr
  Energie als 2T.

Damit existiert ein praktisch starker Kompromisspunkt. Das unterstützt eine
zielabhängige Threadwahl, nicht die Behauptung, dass zwingend nur zwei extreme
Konfigurationen zur Wahl stehen.

Auf AMD fallen Laufzeit- und Energie-Punktoptimum ab 32M jeweils auf 4T
zusammen.

## 8. Stabilität

39 von 162 Konfigurationen überschreiten 5 % Session-CV bei Laufzeit oder
Energie:

```text
AMD:   24
Intel: 15
GPU:    0
```

Korrektur zur Claude-Formulierung: Nicht alle GPU-CVs liegen unter 0.7 %.
Der höchste reproduzierte GPU-CV liegt bei ungefähr 1.01 %; sämtliche GPU-
Konfigurationen bleiben dennoch deutlich unter der eingefrorenen 5%-Schwelle.

Besonders variable exakte Gewinnerkonfigurationen müssen in Abbildungen durch
Intervalle oder Stabilitätskennzeichnung sichtbar bleiben.

## 9. Cache- und Bandbreiteninterpretation

### 9.1 Was eingefroren wird

Die beobachteten Placement-Wechsel sind **konsistent mit**
Working-Set-/Cache-Kapazitätsübergängen:

- kleine Größen zeigen Cache-Effekte;
- AMD führt bei 4M und 8M;
- ab 16M stabilisiert sich in diesem Hardwareset das große Speicherregime.

Die Formulierung muss lauten:

> Die Crossover richten sich nach hardwarespezifischen Working-Set-Regimen und
> stimmen mit Cache-Kapazitätsübergängen überein.

### 9.2 Was nicht als kausal bewiesen eingefroren wird

Nicht zulässig ohne zusätzliche Hardwaremetadaten und Counter:

> Jeder Crossover wird direkt und ausschließlich durch die nominelle LLC-/L2-
> Kapazität verursacht.

Die AMD-L3-Kapazität ist verteilt, Cacheassoziativität und Ersetzung sind nicht
modelliert, und physischer Verkehr wurde nicht gemessen.

### 9.3 Nominale Peak-Ausnutzung bleibt vorläufig

Die gemessenen logischen Nutzdatenraten bei 256M sind reproduziert:

```text
Intel:       26.49 GB/s
AMD:         41.85 GB/s
RTX 3090:   848.88 GB/s
RTX 5060 Ti:395.77 GB/s
```

Exakte Prozentangaben gegenüber einem nominellen Peak werden **nicht** als
finaler Paperclaim eingefroren, weil im Reproduktionsbundle die tatsächliche
CPU-DIMM-Bestückung, Speichergeschwindigkeit und gemessene Maschinenreferenz
fehlen. Zudem ist 12N ein semantischer Anker, kein physischer Traffic-Counter.

Die Claude-Zahlen `CPU 31–44 %` und `GPU 88–91 %` sind daher nur ein
explorativer Plausibilitätscheck. Insbesondere ist die angegebene AMD-Prozentzahl
nicht konsistent mit 41.85 GB/s geteilt durch einen nominellen
102.4-GB/s-Quad-Channel-Peak.

Auch die Aussage, ordinary stores verursachten nachweislich exakt 16N
physischen Verkehr, ist ohne Disassembly oder Hardwarecounter zu stark. Der
Quellcode fordert keine Non-Temporal Stores an; das tatsächliche
Write-Allocate-Verhalten wurde jedoch nicht gemessen.

## 10. Energiedomänen

Cross-Platform-Primärdomänen:

```text
Intel:      Package-RAPL
AMD:        Package-RAPL
RTX GPUs:   NVML-Boardenergie inklusive Gerätespeicher
```

Diese Grenzen sind nicht whole-system-äquivalent.

Für Intel liegt `package + DRAM` gegenüber Package-only auf Ebene der 315
Sessionmediane:

```text
Mittel: 1.805 %
Maximum: 2.829 %
```

Daher wird die frühere ungefähre Formulierung `typischerweise 1.9–2.1 %`
ersetzt durch:

> Auf Sessionmedianebene erhöht die zusätzliche Intel-DRAM-Zone die gemessene
> Energie im Mittel um 1.81 %, maximal um 2.83 %.

AMD besitzt in diesem Datensatz keine entsprechende separate DRAM-Zone.

## 11. Statistische Qualifikationen

- Die Experimentaleinheit ist der Sessionmedian (`n=5`).
- Die Konfigurationsmedian-Intervalle enumerieren alle `5^5=3125`
  Bootstrap-Resamples exakt.
- Bei fünf Beobachtungen sind diese Intervalle grob und diskret; sie dürfen
  nicht als hochauflösende Unsicherheitsquantifizierung dargestellt werden.
- Die gespeicherten Pairwise-Ratio-Intervalle verwenden 20.000 deterministisch
  gesampelte Bootstrap-Draws. Eine unabhängige exakte diskrete Gegenrechnung
  bestätigt die gespeicherten Quantilgrenzen.
- Native-best- und Exact-winner-Auswertungen sind post-selection und
  deskriptiv, nicht konfirmatorische Hardwarepopulations-Inferenz.
- Cliff's Delta und `probability_a_better` besitzen bei 5x5 Paaren eine
  Auflösung von 1/25 = 0.04.

## 12. Verbindliche Reporting-Patches

Vor Verwendung im Paper beziehungsweise im finalen Ergebnisbericht:

1. Within-Platform-Abschnitt um die deskriptive Exact-winner-Strafe ergänzen;
2. die konservative Leader-Set-Aussage daneben beibehalten;
3. leere Leader-Überlappungen als `none` oder `∅` statt `NaN` rendern;
4. Konfidenzintervalle oder ein Stabilitätspanel in die Hauptabbildungen
   aufnehmen;
5. Post-Selection-Hinweis auch in Captions aufnehmen;
6. Intel-DRAM-Sensitivität auf Mittel 1.81 %, Maximum 2.83 % korrigieren;
7. Cacheerklärung als Konsistenz-/Mechanismushypothese, nicht als kausalen
   Beweis formulieren;
8. nominelle Peak-Ausnutzung nicht ohne dokumentierte DIMM- und
   Referenzbandbreite als finalen CPU-Claim verwenden;
9. `severity` in `integrity_checks.csv` bei Gelegenheit zu
   `severity_if_failed` umbenennen.

Punkte 1 bis 8 beeinflussen keine Rohmessung und erfordern keinen Rerun.


## 12.1 Repository-Konsistenz

Die älteren Dateien `Plan-v8.2-FINAL-POLISHED.md` und
`CSV_SCHEMA_FINAL(2).md` sind für den eingefrorenen STREAM-Stand nicht
autoritativ. Sie enthalten unter anderem die ältere Carbon-/ML-Framework-Story,
eine RTX-5050-Zielplattform, ein 42-Spalten-`cpu-gpu-v1`-Schema und die alte
REDUCTION-Definition `dot-with-ones`.

Für STREAM gelten stattdessen ausschließlich:

```text
cpu-gpu-v2
45 Spalten
RTX 3090 + RTX 5060 Ti
5 unabhängige Sessions x 10 technische Wiederholungen
```

Die Altdateien müssen im Repository entweder als `deprecated` markiert oder
durch aktualisierte Projektdokumente ersetzt werden.

## 13. Eingefrorene publikationsfähige Claims

> Across nine problem sizes, the runtime- and energy-optimal hardware
> placements for resident FP32 STREAM Triad diverge clearly at six sizes.

> For resident working sets of 192 MB and above, the RTX 3090 delivers
> 2.11–2.15x the logical useful-data rate of the RTX 5060 Ti, whereas the RTX
> 5060 Ti consumes 38.5–39.3% less board energy; the RTX 3090 nevertheless
> achieves a 22.0–24.2% lower EDP.

> The observed placement changes align with hardware-specific working-set and
> cache-capacity regimes; in this system set, no tested platform remains in the
> small-working-set regime from 16M elements onward.

> Within Intel, the exact runtime- and energy-minimizing thread counts differ
> at seven of nine sizes. In a descriptive post-selection comparison, choosing
> the exact runtime winner incurs a clearly greater-than-2% energy premium at
> five sizes, ranging from 6.9% to 50.3%.

> All energy comparisons refer to the measured device domains—CPU package RAPL
> and GPU board energy—and not to equivalent whole-system energy boundaries.

## 14. Verbotene oder abzuschwächende Claims

Nicht verwenden:

- `12N` sei gemessener physischer Speicherverkehr;
- STREAM erreiche auf den CPUs definitiv einen bestimmten Anteil des
  tatsächlich verfügbaren DRAM-Peaks, solange DIMM-Metadaten fehlen;
- gewöhnliche Stores bewiesen ohne Counter exakt 16N physischen Verkehr;
- jeder Crossover werde kausal allein durch Cachekapazität erklärt;
- GPU-Resultate enthielten PCIe-Transfers;
- CPU-Package und GPU-Board seien identische Energiegrenzen;
- fünf Sessions erlaubten Hardwarepopulations-Inferenz;
- Runtime und logische Bandbreite seien unabhängige Evidenz;
- Energie und logische GB/J seien unabhängige Evidenz;
- EDP sei eine unabhängig gemessene physische Größe;
- die Exact-winner-Strafen seien präregistrierte konfirmatorische Tests.

## 15. Restgrenzen des Audits

Das 20-Dateien-Bundle enthält nicht:

- die 8.100 Rohzeilen;
- `benchmark_common.hpp`;
- vollständige DIMM-Konfiguration und CPU-Speichertakt;
- vollständige Buildmanifeste und Disassembly;
- physische DRAM-/VRAM-Traffic-Counter.

Daher sind Rohchecksummen, RAPL-Interna, jede Rohzeilenidentität und kausale
Traffic-/Cache-Zuordnung nicht vollständig autonom reproduzierbar.

Diese Grenzen verlangen für die bestehenden STREAM-Hauptclaims keinen Rerun.
Für Peak-Ausnutzungs- oder physische-Traffic-Claims wären zusätzliche Metadaten,
Counter oder eine Referenzmessung nötig.

## 16. Freeze-Entscheidung

**STREAM ist für die deskriptive Cross-Platform-Auswertung und die
objective-dependent Placement-Story freigegeben.**

Keine Messkampagne und keine bestehende Analyseformel wird geändert. Neue
Änderungen am STREAM-Ergebnisstand dürfen nur erfolgen, wenn:

1. ein reproduzierbarer Code- oder Datenfehler nachgewiesen wird; oder
2. ein zusätzlicher, klar als Erweiterung versionierter Analysebaustein
   aufgenommen wird.

Die beigelegte Exact-winner-Regret-Auswertung ist eine solche versionierte,
deskriptive Reporting-Erweiterung und verändert keine bestehenden Tabellen.
