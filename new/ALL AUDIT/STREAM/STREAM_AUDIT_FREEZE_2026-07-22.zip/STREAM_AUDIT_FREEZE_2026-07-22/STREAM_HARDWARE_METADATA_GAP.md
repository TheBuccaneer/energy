# STREAM Hardware Metadata Gap

Die statistischen Hauptclaims sind eingefroren. Für optionale Peak-Bandbreiten-
und stärkere Cachemechanismus-Claims fehlen jedoch Maschinenmetadaten.

Vor solchen Claims im Paper im Repo dokumentieren:

```bash
lscpu
sudo dmidecode --type memory
sudo lshw -class memory
nvidia-smi -q
```

Zusätzlich sinnvoll:

- vollständige DIMM-Slotbelegung;
- tatsächliche DDR-Datenrate und Kanalzahl;
- BIOS-/NUMA-Konfiguration;
- CUDA `deviceQuery` mit L2-Größe und Memory-Bus-Angaben;
- vollständige Compilerflags;
- optional Referenz-STREAM beziehungsweise Hardwarecounter.

Bis dahin dürfen gemessene **logische GB/s** berichtet werden, aber keine
präzisen CPU-Prozentwerte gegenüber einem angenommenen nominellen Peak.
