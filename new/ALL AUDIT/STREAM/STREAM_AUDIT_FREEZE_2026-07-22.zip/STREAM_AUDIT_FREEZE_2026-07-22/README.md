# STREAM Audit Freeze Package

Empfohlene Ablage im Repository:

```text
audit/STREAM/
├── AUDIT_STREAM_FINAL_FROZEN_2026-07-22.md
├── STREAM_REPORTING_PATCHES_FROZEN.md
├── STREAM_HARDWARE_METADATA_GAP.md
├── external/
│   ├── CLAUDE_STREAM_AUDIT_2026-07-22.md
│   └── PRIOR_STREAM_AUDIT_2026-07-21.md
└── extensions/
    ├── stream_within_platform_exact_winner_regret.py
    └── within_platform_exact_winner_regret.csv
```

Reproduktion der Erweiterung:

```bash
python audit/STREAM/extensions/stream_within_platform_exact_winner_regret.py \
  --session-medians <path>/unified_session_medians.csv \
  --configuration-summary <path>/unified_configuration_summary.csv \
  --output audit/STREAM/extensions/within_platform_exact_winner_regret.csv
```

Die Erweiterung ist deskriptiv und post-selection. Sie ersetzt keine bestehende
Leader- oder Placement-Tabelle.
