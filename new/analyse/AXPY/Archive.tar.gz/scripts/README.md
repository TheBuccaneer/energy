# AXPY-Auswertung v4 – gehärtete Referenzanalyse

Für Intel i9-7900X, AMD Threadripper 3970X, RTX 3090 und RTX 5060 Ti.

## Audit-Patches in v4

- GPU-Quickchecks werden auch ohne Shell-PASS-Marker korrekt erkannt, wenn das
  Log sechs AXPY-Messzeilen, ausschließlich Checksummen `OK`, Anti-Collapse
  `gate=PASS` und kein `FATAL` enthält.
- Provenienzfelder sind präzise getrennt: Manifest gelesen, Session-Hashes,
  Source-, Runner- und Binary-Status. Nichts wird pauschal als „verified“
  bezeichnet.
- Ein expliziter `axpy_campaign_lock.json` friert Kampagnen-IDs sowie SHA-256
  aller Session-CSVs und Logs ein.
- Wiederholungen können mit `AXPY_CAMPAIGN_LOCK=...` exakt dieselben Kampagnen
  auswählen, statt wieder die jüngste Kampagne zu nehmen.
- CPU-/GPU-Telemetrie bleibt vollständig erhalten. Neu entstehen
  `axpy_telemetry_summary.csv`, `axpy_telemetry_by_config.csv` und
  `axpy_telemetry_report.md`.
- Hohe CPU-Temperaturen und ein möglicher heiß/kühl-Taktabfall werden kompakt
  markiert, ohne automatisch Messdaten zu verwerfen.
- Session-Robustheit trennt nun:
  - feste global ausgewählte Konfiguration;
  - per-Session neu optimiertes Oracle-Envelope.
- Gewinner werden getrennt als `directionally_robust` und `fully_robust`
  ausgewiesen. So wird eine stabile Richtung nicht mit einer stabilen
  Effektgröße verwechselt.
- Die primäre In-Range-Sensitivität verlangt 5/5 Sessions. Teilabdeckung wird
  separat dokumentiert und nicht in das Primär-Envelope aufgenommen.
- Plots beschriften die tatsächlichen Dezimalgrößen `1M … 256M` und zeigen
  Bootstrap-Unsicherheitsbalken.
- `ANALYSIS_COMPLETE.json` übernimmt Warnstatus und Warnanzahl der Teilanalysen.
- `AXPY_ANALYSIS_HANDOVER.zip` enthält Skripte, Ergebnisse, Kampagnen-Lock und
  vorhandene Kampagnenmanifeste.
- Ausgabe bleibt atomar; bei Fehler bleibt die Diagnose unter
  `new/analyse/AXPY/all_platforms_FAILED_LAST/` erhalten.

## Installation

```bash
cd ~/projects/energy
mkdir -p new/analyse/AXPY/scripts
unzip -o ~/Downloads/AXPY_ANALYSIS_ALL_PLATFORMS_PATCHED_v4.zip \
  -d new/analyse/AXPY/scripts
chmod +x new/analyse/AXPY/scripts/run_all_axpy_analysis.sh
```

## Ausführen

```bash
cd ~/projects/energy
bash new/analyse/AXPY/scripts/run_all_axpy_analysis.sh
```

Optional schneller Entwicklungsdurchlauf:

```bash
BOOTSTRAP_RESAMPLES=500 \
  bash new/analyse/AXPY/scripts/run_all_axpy_analysis.sh
```

Für die finale Auswertung den Standard `5000` verwenden.

## Exakt dieselben Kampagnen erneut analysieren

Nach dem ersten vollständigen Lauf:

```bash
AXPY_CAMPAIGN_LOCK=~/projects/energy/new/analyse/AXPY/all_platforms/axpy_campaign_lock.json \
  bash new/analyse/AXPY/scripts/run_all_axpy_analysis.sh
```

## Zentrale Ausgaben

- `axpy_campaign_lock.json`
- `axpy_provenance_report.md`
- `axpy_validation_report.md`
- `axpy_telemetry_report.md`
- `axpy_comparison_report.md`
- `axpy_robustness_report.md`
- `axpy_winner_robustness.csv`
- `axpy_in_range_sensitivity.csv`
- `axpy_global_pareto.csv`
- `axpy_cross_platform_by_size.csv`
- `ANALYSIS_COMPLETE.json`
- `AXPY_ANALYSIS_HANDOVER.zip`

Nur ein Ordner mit `ANALYSIS_COMPLETE.json` und
`axpy_handover_complete.json` ist als vollständiger Lauf zu behandeln.

## Wissenschaftliche Semantik

Primärzeit ist E2E-Zeit pro logischer AXPY-Operation. Primärenergie ist
CPU-Package beziehungsweise GPU-Board pro Operation. Das ist kein vollständiger
Systemenergievergleich: Bei CPUs fehlt insbesondere externe DDR4-Energie,
während GPU-VRAM im Board-Zähler enthalten ist.

Die Bootstrap-Intervalle sind Unsicherheitsintervalle über fünf
Session-Mediane und kein alleiniger Signifikanznachweis. „Logische Bandbreite“
bezieht sich auf den semantischen Byteanker `12N`, nicht auf gemessenen
physischen DRAM-/VRAM-Verkehr.
