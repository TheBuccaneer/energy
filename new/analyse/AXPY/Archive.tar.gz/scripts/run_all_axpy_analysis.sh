#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO="${1:-$(git -C "$SCRIPT_DIR" rev-parse --show-toplevel 2>/dev/null || pwd)}"
OUTPUT_REL="${2:-new/analyse/AXPY/all_platforms}"
BOOTSTRAP_RESAMPLES="${BOOTSTRAP_RESAMPLES:-5000}"
FINAL="$REPO/$OUTPUT_REL"
PARENT=$(dirname "$FINAL")
BASE=$(basename "$FINAL")
STAGE="$PARENT/.${BASE}.tmp.$$"
OLD="$PARENT/.${BASE}.old.$$"
FAILED="$PARENT/${BASE}_FAILED_LAST"
CAMPAIGN_ARGS=()

command -v python3 >/dev/null || {
  echo "ERROR: python3 fehlt." >&2
  exit 2
}

if [[ -n "${AXPY_CAMPAIGN_LOCK:-}" ]]; then
  [[ -f "$AXPY_CAMPAIGN_LOCK" ]] || {
    echo "ERROR: AXPY_CAMPAIGN_LOCK fehlt: $AXPY_CAMPAIGN_LOCK" >&2
    exit 2
  }
  mapfile -t CAMPAIGN_ARGS < <(python3 - "$AXPY_CAMPAIGN_LOCK" <<'PYLOCK'
import json, pathlib, sys
lock=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'))
flags={'intel':'--intel-campaign','amd':'--amd-campaign','3090':'--gpu3090-campaign','5060ti':'--gpu5060ti-campaign'}
found={item['platform']: item['campaign_id'] for item in lock.get('campaigns',[])}
missing=set(flags)-set(found)
if missing:
    raise SystemExit(f"Campaign-Lock unvollständig: {sorted(missing)}")
for key in ('intel','amd','3090','5060ti'):
    print(flags[key]); print(found[key])
PYLOCK
  )
  echo "[lock] Verwende eingefrorene Kampagnen aus: $AXPY_CAMPAIGN_LOCK"
fi

echo "[selftest] Prüfe v4-Regressionsanker..."
python3 "$SCRIPT_DIR/selftest_axpy_analysis_v4.py"

mkdir -p "$PARENT"
rm -rf "$STAGE" "$OLD"
mkdir -p "$STAGE"

cleanup() {
  rc=$?
  if [[ $rc -ne 0 && -d "$STAGE" ]]; then
    rm -rf "$FAILED"
    mv "$STAGE" "$FAILED"
    echo >&2
    echo "Analyse abgebrochen. Diagnose wurde erhalten unter:" >&2
    echo "  $FAILED" >&2
  else
    rm -rf "$STAGE"
  fi
}
trap cleanup EXIT INT TERM

echo "[1/5] Prüfe Provenienz, Logs, Manifeste und Quickcheck-Bezug..."
python3 "$SCRIPT_DIR/00_validate_axpy_provenance.py" \
  --repo "$REPO" \
  --output "$STAGE" \
  "${CAMPAIGN_ARGS[@]}"

echo "[2/5] Validiere Semantik, Telemetrie und aggregiere session-bewusst..."
python3 "$SCRIPT_DIR/01_validate_and_aggregate_axpy.py" \
  --repo "$REPO" \
  --output "$STAGE" \
  --bootstrap-resamples "$BOOTSTRAP_RESAMPLES" \
  "${CAMPAIGN_ARGS[@]}"

test -f "$STAGE/axpy_validation_complete.json" || {
  echo "ERROR: Validierungsmarker fehlt." >&2
  exit 2
}

echo "[3/5] Erzeuge Punktvergleich, Pareto-Tabellen und Plots..."
python3 "$SCRIPT_DIR/02_compare_axpy_all.py" \
  --input "$STAGE/axpy_config_summary.csv" \
  --output "$STAGE"

echo "[4/5] Ergänze fixed-config-/oracle-/CI-/In-Range-Robustheit..."
python3 "$SCRIPT_DIR/03_assess_axpy_robustness.py" \
  --config "$STAGE/axpy_config_summary.csv" \
  --session "$STAGE/axpy_session_summary.csv" \
  --normalized "$STAGE/axpy_normalized_rows.csv" \
  --cross "$STAGE/axpy_cross_platform_by_size.csv" \
  --pareto "$STAGE/axpy_global_pareto.csv" \
  --comparison-report "$STAGE/axpy_comparison_report.md" \
  --output "$STAGE"

python3 - "$STAGE" "$SCRIPT_DIR" <<'PYMARK'
import csv
import hashlib
import json
import pathlib
import sys
import time

out = pathlib.Path(sys.argv[1])
scripts = pathlib.Path(sys.argv[2])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name):
    return json.loads((out/name).read_text(encoding='utf-8'))

def count_issues(name):
    path=out/name
    if not path.exists(): return {'FAIL':0,'WARN':0}
    counts={'FAIL':0,'WARN':0}
    with path.open(newline='',encoding='utf-8') as handle:
        for row in csv.DictReader(handle):
            severity=row.get('severity','')
            if severity in counts: counts[severity]+=1
    return counts

provenance=load('axpy_provenance_complete.json')
validation=load('axpy_validation_complete.json')
robustness=load('axpy_robustness_complete.json')
prov_issues=count_issues('axpy_provenance_issues.csv')
val_issues=count_issues('axpy_validation_issues.csv')
warning_count=(prov_issues['WARN']+val_issues['WARN']+int(robustness.get('warnings',0)))
fail_count=prov_issues['FAIL']+val_issues['FAIL']
status='FAIL' if fail_count else ('PASS_WITH_WARNINGS' if warning_count else 'PASS')
used = [
    '00_validate_axpy_provenance.py',
    '01_validate_and_aggregate_axpy.py',
    '02_compare_axpy_all.py',
    '03_assess_axpy_robustness.py',
    '04_build_axpy_handover.py',
    'axpy_analysis_common.py',
    'run_all_axpy_analysis.sh',
    'selftest_axpy_analysis_v4.py',
]
marker = {
    'status': status,
    'created_unix': time.time(),
    'failures': fail_count,
    'warnings': warning_count,
    'component_status': {
        'provenance': provenance.get('status'),
        'validation': validation.get('status'),
        'robustness': robustness.get('status'),
    },
    'campaign_lock_sha256': sha(out/'axpy_campaign_lock.json'),
    'script_sha256': {name: sha(scripts/name) for name in used},
}
(out/'ANALYSIS_COMPLETE.json').write_text(json.dumps(marker,indent=2,sort_keys=True)+'\n')
PYMARK

echo "[5/5] Erzeuge eingefrorenes Handover-Archiv..."
python3 "$SCRIPT_DIR/04_build_axpy_handover.py" \
  --output-dir "$STAGE" \
  --scripts-dir "$SCRIPT_DIR"

# Erst nach vollständigem PASS/PASS_WITH_WARNINGS wird der bisherige Ordner ersetzt.
if [[ -e "$FINAL" ]]; then
  mv "$FINAL" "$OLD"
fi
if ! mv "$STAGE" "$FINAL"; then
  [[ -e "$OLD" ]] && mv "$OLD" "$FINAL"
  exit 2
fi
rm -rf "$OLD" "$FAILED"
trap - EXIT INT TERM

FINAL_STATUS=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["status"])' "$FINAL/ANALYSIS_COMPLETE.json")
echo
echo "$FINAL_STATUS: atomare AXPY-Auswertung abgeschlossen."
echo "  $FINAL/axpy_validation_report.md"
echo "  $FINAL/axpy_telemetry_report.md"
echo "  $FINAL/axpy_comparison_report.md"
echo "  $FINAL/axpy_robustness_report.md"
echo "  $FINAL/AXPY_ANALYSIS_HANDOVER.zip"
