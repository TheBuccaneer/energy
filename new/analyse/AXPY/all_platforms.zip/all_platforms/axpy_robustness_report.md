# AXPY – Robustheit und Sensitivität

Punktgewinner werden zusätzlich gegen drei unabhängige Robustheitsanker geprüft: Gewinner in allen fünf Sessions, CV ≤ 10 % am ausgewählten Betriebspunkt und konservativ getrennte Bootstrap-Intervalle. `robust_winners` erfüllt alle drei Bedingungen.

| N | Laufzeit: Punkt → robust | Energie: Punkt → robust | EDP: Punkt → robust | In-Range-Sensitivität |
|---:|---|---|---|---|
| 1000000 | 5060ti → 5060ti | 5060ti → 5060ti | 5060ti → 5060ti | gleich |
| 2000000 | 5060ti → 5060ti | 5060ti → 5060ti | 5060ti → 5060ti | gleich |
| 4000000 | 5060ti → – | 5060ti → – | 5060ti → – | gleich |
| 8000000 | amd → – | amd → – | amd → – | gleich |
| 16000000 | 3090 → 3090 | 5060ti → 5060ti | 3090 → 3090 | gleich |
| 32000000 | 3090 → 3090 | 5060ti → 5060ti | 3090 → 3090 | gleich |
| 64000000 | 3090 → 3090 | 5060ti → 5060ti | 3090 → 3090 | gleich |
| 128000000 | 3090 → 3090 | 5060ti → 5060ti | 3090 → 3090 | gleich |
| 256000000 | 3090 → 3090 | 5060ti → 5060ti | 3090 → 3090 | gleich |

## GPU-Throttle-Masken

| Plattform | Maske | Dekodierung | Zeilen |
|---|---|---|---:|
| 3090 | `0x4` | software_power_cap | 450 |
| 5060ti | `0x0` | none | 450 |

## Einordnung

- In-Range-only-Sensitivitätsabweichungen: **0** von 27 Metrik×Größe-Fällen.
- Ein leerer `robust_winners`-Eintrag widerlegt den Punktgewinner nicht; er bedeutet, dass bei nur fünf Sessions mindestens einer der konservativen Zusatzanker nicht vollständig erfüllt ist.
- Die Intervalle sind Bootstrap-Unsicherheitsintervalle über fünf Session-Zusammenfassungen, kein alleiniger Signifikanznachweis.
