# AXPY – Provenienzprüfung

**Status: PASS MIT WARNUNGEN**

| Plattform | Kampagne | Manifest | CSV-Hashes | Logs | Quickcheck | Status |
|---|---|---|---:|---:|---|---|
| Intel i9-7900X | `axpy_intel_20260725_163341` | nein | 0/5 | 5/5 | historical_failure | partial |
| AMD Threadripper 3970X | `axpy_amd_20260725_215406` | nein | 0/5 | 5/5 | missing | partial |
| RTX 3090 | `axpy_3090_20260727_133600` | ja | 5/5 | 5/5 | historical_failure | partial |
| RTX 5060 Ti | `axpy_5060ti_20260727_141707` | ja | 5/5 | 5/5 | historical_failure | partial |

Fehlende historische CPU-Manifeste oder fehlgeschlagene historische Quickchecks bleiben dokumentierte Provenienzlücken; sie erzwingen keine Neumessung. Widersprüche in offiziellen Session-Logs, Manifest-Hashes, Gerätebindung oder GPU-Sourceidentität bleiben harte Fehler.

FAIL: 0; WARN: 6
- **WARN [intel/manifest]:** Manifest fehlt: axpy_intel_20260725_163341_manifest.txt
- **WARN [intel/quickcheck]:** Kein vollständig bestandener Quickcheck vor Kampagnenbeginn gefunden. Historische Kandidaten: axpy_intel_20260725_163341_quickcheck.log. Dies ist kein Fehler der offiziellen Session-Daten.
- **WARN [amd/manifest]:** Manifest fehlt: axpy_amd_20260725_215406_manifest.txt
- **WARN [amd/quickcheck]:** Kein Quickcheck-Log gefunden. Kampagne bleibt analysierbar, Provenienzstatus ist aber nur partial.
- **WARN [3090/quickcheck]:** Kein vollständig bestandener Quickcheck vor Kampagnenbeginn gefunden. Historische Kandidaten: axpy_3090_20260727_122403_quickcheck.log. Dies ist kein Fehler der offiziellen Session-Daten.
- **WARN [5060ti/quickcheck]:** Kein vollständig bestandener Quickcheck vor Kampagnenbeginn gefunden. Historische Kandidaten: axpy_5060ti_20260727_140945_quickcheck.log. Dies ist kein Fehler der offiziellen Session-Daten.
