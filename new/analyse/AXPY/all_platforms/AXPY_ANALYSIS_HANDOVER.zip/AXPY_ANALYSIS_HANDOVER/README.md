# AXPY analysis handover

Dieses Archiv friert die ausgewählten Kampagnen, die Rohdatei-Hashes,
die Analyse-Skripte und sämtliche abgeleiteten Ergebnisse zusammen ein.
Die großen Roh-CSVs und Session-Logs werden nicht dupliziert; ihre Pfade und
SHA-256-Prüfsummen stehen in `results/axpy_campaign_lock.json`. Die ausgewählten
Quickcheck-Logs werden dagegen direkt unter `quickcheck_logs/` mitgeführt.

Für eine vollständige Wiederholung müssen die dort referenzierten Rohdateien
am Repository-Standort vorhanden sein. Dann kann der Lock über
`AXPY_CAMPAIGN_LOCK=/pfad/axpy_campaign_lock.json` an den Runner übergeben werden.
