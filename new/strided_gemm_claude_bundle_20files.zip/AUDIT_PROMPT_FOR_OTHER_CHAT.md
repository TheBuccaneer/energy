# Independent audit prompt for another ChatGPT/Claude conversation

Please audit the attached STRIDED_GEMM analysis package and generated results independently. Do not trust the generated prose before reproducing the central calculations from the CSV files and Python code.

Separate your verdict into:

1. validity of each raw campaign;
2. validity of each individual-platform analysis;
3. validity of the combined four-platform analysis;
4. validity of the dense-GEMM versus STRIDED_GEMM comparison;
5. admissible paper claims.

Verify at least the following:

- five complete sessions and ten repetitions per configuration;
- AMD: 9 sizes × 9 thread counts × 10 repetitions × 5 sessions;
- Intel: 9 sizes × 7 thread counts × 10 repetitions × 5 sessions;
- each GPU: 9 sizes × 10 repetitions × 5 sessions;
- no quickcheck file included in official campaigns;
- `workload=STRIDED_GEMM`;
- CPU implementation `openblas_sgemm_ld2n`;
- GPU implementation `cublas_gemm_ex_fp32_pedantic_ld2n`;
- `problem_spec=N=<N>;ld=<2N>`;
- `2*N^3` FLOPs per logical GEMM;
- `12*N^2` logical bytes and `24*N^2` allocated A+B+C footprint;
- no inference of measured physical traffic from either quantity;
- formulas for time, energy, power, FLOPs, throughput and EDP;
- all checksums true;
- GPU source identity and pedantic FP32/TF32-disable provenance;
- no session pause;
- session IDs validated by campaign timestamp and `_sessionN` suffix rather than an unnecessarily rigid prefix;
- AMD absence of DRAM RAPL is not treated as a data failure;
- CPU cross-platform primary energy is package RAPL;
- GPU cross-platform energy is NVML board energy;
- the CPU/GPU energy-boundary asymmetry is explicit;
- five session medians are the primary units;
- exact bootstrap enumeration at n=5 or an equivalent deterministic implementation;
- ratio-CI classification and ±2% practical-equivalence rule;
- no double counting of runtime/throughput or energy/GFLOP-J;
- EDP treated as a composite;
- native-best intervals labeled descriptive post-selection;
- configuration-matched dense-vs-strided comparisons use the same platform, N and CPU thread configuration;
- dense and strided sessions are treated as independent rather than falsely paired by session number;
- layout-induced platform or thread-selection changes are reproduced from the CSVs;
- Pareto classifications are internally consistent with runtime and energy.

Pay special attention to unexpected `clear_strided_lower` cases. They are not automatically invalid because libraries may pack data or choose different kernels, but they require raw-session, clock, temperature and power inspection.

End with exactly these sections:

## Verdict
PASS / PASS WITH CHANGES / FAIL

## Measurement issues
Only actual raw-data problems.

## Analysis-code issues
Concrete calculation or classification problems.

## Accepted claims
Claims supported by the data.

## Claims requiring qualification
Measurement-domain, post-selection, thermal or resident-mode limitations.

## Required corrections
Only blockers or necessary fixes.

## Optional sensitivity analyses
Clearly separated from blockers.
